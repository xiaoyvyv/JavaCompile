package sample;

/**
 * Java Hello World example.
 */
public class HelloWorldExample {

    public static void main(String args[]) {

    /*
    Use System.out.println() to print on console.
    */
        System.out.println("Hello World !");
    }
}

/*

 OUTPUT of the above given Java Hello World Example would be :

 Hello World !

 */
